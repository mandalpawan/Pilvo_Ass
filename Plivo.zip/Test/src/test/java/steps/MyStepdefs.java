package steps;


import Test.services.AllService;
import Test.utiles.CSVWriter;
import Test.utiles.ExcelReader;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import java.util.List;
import java.io.File;

import static Test.utiles.Request.postAPI;
import static org.junit.Assert.*;

import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MyStepdefs {
    AllService allService = new AllService();
    private List<List<String>> csvData;
    private String fileName;
    private  ExcelReader excelReader = new ExcelReader();

    private String channelId;
    private Response response;

    @Given("the following data for the CSV file")
    public void the_following_data_for_the_CSV_file(DataTable dataTable) {
        csvData = dataTable.asLists(String.class);
    }

    @When("I create the CSV file named {string}")
    public void i_create_the_CSV_file_named(String fileName) {
        this.fileName = fileName;

        // Extract headers and data
        String[] headers = csvData.get(0).toArray(new String[0]);
        String[][] data = new String[csvData.size() - 1][];
        for (int i = 1; i < csvData.size(); i++) {
            data[i - 1] = csvData.get(i).toArray(new String[0]);
        }

        // Call the CSV creation function
        CSVWriter.createCSV(fileName, headers, data);
    }

    @Then("the file {string} should be created with the provided data")
    public void the_file_should_be_created_with_the_provided_data(String expectedFileName) {
        File file = new File(expectedFileName);
        assertTrue("CSV file should exist", file.exists());

        // Verify the content of the file
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                String[] expectedValues = csvData.get(lineNumber).toArray(new String[0]);
                lineNumber++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Given("the data from Excel file {string}")
    public void the_data_from_Excel_file(String excelFileName) {
        csvData = ExcelReader.readCSV();
    }


    private String convertCsvDataToJson(List<List<String>> csvData) {

        StringBuilder jsonBuilder = new StringBuilder();
        jsonBuilder.append("[");
        for (int i = 1; i < csvData.size(); i++) { // skipping headers
            jsonBuilder.append("{");
            for (int j = 0; j < csvData.get(i).size(); j++) {
                jsonBuilder.append("\"").append(csvData.get(0).get(j)).append("\": \"")
                        .append(csvData.get(i).get(j)).append("\"");
                if (j < csvData.get(i).size() - 1) {
                    jsonBuilder.append(", ");
                }
            }
            jsonBuilder.append("}");
            if (i < csvData.size() - 1) {
                jsonBuilder.append(", ");
            }
        }
        jsonBuilder.append("]");
        return jsonBuilder.toString();
    }



    @Then("send all the message to the user")
    public void sendAllTheMessageToTheUser() {
        AllService.sendsms(convertCsvDataToJson(excelReader.readCSV()));
    }



    ////////////////////////



    @Given("I have created a new channel named {string}")
    public void i_have_created_a_new_channel_named(String channelName) {

        String URL = "https://api.plivo.com";
        String endpoint = "/v1/Account/{auth_id}/Message/";
        // Send POST request to create a new channel
        response = postAPI("",URL,endpoint);

        channelId = response.jsonPath().getString("id");
        assertNotNull("Channel ID should not be null", channelId);
    }

    @When("I join the newly created channel")
    public void i_join_the_newly_created_channel() {

        String URL = "https://api.plivo.com";
        String endpoint = "/v1/Account/{auth_id}/Message/";
        // Send POST request to create a new channel
        response = postAPI("",URL,endpoint);
        assertEquals("Join request should be successful", 200, response.getStatusCode());
    }

    @When("I rename the channel to {string}")
    public void i_rename_the_channel_to(String newChannelName) {
        // Prepare request payload
        String URL = "https://api.plivo.com";
        String endpoint = "/v1/Account/{auth_id}/Message/";
        // Send POST request to create a new channel
        response = postAPI("",URL,endpoint);
        assertEquals("Rename request should be successful", 200, response.getStatusCode());
    }

    @Then("I should see the channel name as {string} in the list of channels")
    public void i_should_see_the_channel_name_as_in_the_list_of_channels(String expectedChannelName) {
        String URL = "https://api.plivo.com";
        String endpoint = "/v1/Account/{auth_id}/Message/";
        // Send POST request to create a new channel
        response = postAPI("",URL,endpoint);
        assertEquals("List channels request should be successful", 200, response.getStatusCode());

        // Validate if the channel name has changed
        List<String> channelNames = response.jsonPath().getList("name");
        assertTrue("Channel name should be updated", channelNames.contains(expectedChannelName));
    }

    @When("I archive the channel")
    public void i_archive_the_channel() {
        String URL = "https://api.plivo.com";
        String endpoint = "/v1/Account/{auth_id}/Message/";

        response = postAPI("",URL,endpoint);
        assertEquals("Archive request should be successful", 200, response.getStatusCode());
    }

    @Then("I should see that the channel is archived successfully")
    public void i_should_see_that_the_channel_is_archived_successfully() {
        String URL = "https://api.plivo.com";
        String endpoint = "/v1/Account/{auth_id}/Message/";
        // Send POST request to create a new channel
        response = postAPI("",URL,endpoint);
        assertEquals("Get channel details request should be successful", 200, response.getStatusCode());

        // Validate if the channel is archived
        String status = response.jsonPath().getString("status");
        assertEquals("Channel status should be 'archived'", "archived", status);
    }
}

