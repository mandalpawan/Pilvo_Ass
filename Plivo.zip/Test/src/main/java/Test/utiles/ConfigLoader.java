package Test.utiles;

import org.testng.annotations.BeforeSuite;

import java.util.Properties;


public class ConfigLoader {
    private  final Properties properties;
    private static  ConfigLoader configLoader;

    public ConfigLoader(){
        properties = PropertyUtils.propertyLoader("D:\\Automation\\Aggregator_Rest_Automatition\\config.properties");
    }

    @BeforeSuite
    public  static ConfigLoader getInstance(){
        if(configLoader==null){
            configLoader = new ConfigLoader();
        }
        return configLoader;
    }

    public String getData(String key){
        String prop = properties.getProperty(key);
        if(prop!=null)
            return prop;
        throw new RuntimeException("Properties not found :"+key);
    }
}
