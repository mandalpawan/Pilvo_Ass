package Test.utiles;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.PrintStream;
import java.util.concurrent.TimeUnit;

import static Test.api.SpecBuilder.getRequestSpec;
import static Test.api.SpecBuilder.getResponseSpec;
import static io.restassured.RestAssured.given;
import org.testng.annotations.BeforeClass;

public class Request {
    private static final Logger logger = LogManager.getLogger(Request.class);

    @BeforeClass
    public void setup() {
        PrintStream logStream = new PrintStream(System.out);

        RestAssured.filters(
                new RequestLoggingFilter(LogDetail.ALL, logStream),
                new ResponseLoggingFilter(LogDetail.ALL, logStream)
        );
    }

    static public Response getAPI(String URL,String endpoint){
        return given(getRequestSpec(URL))
                .when().get(endpoint)
                .then().spec(getResponseSpec())
                .extract().
                response();
    }

    static public Response postAPI(Object data,String URL,String endpoint){


        Response response=   given(getRequestSpec(URL))
                .body(data)
                .when()
                .post(endpoint)
                .then().spec(getResponseSpec())
                .assertThat()
                .extract().
                response();

        logger.info(" **** POST call Response time " + response.timeIn(TimeUnit.MILLISECONDS) + " ms");
        return  response;
    }
}

