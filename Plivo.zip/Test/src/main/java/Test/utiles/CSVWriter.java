package Test.utiles;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CSVWriter {

    // Function to create a CSV file and add data
    public static void createCSV(String fileName, String[] headers, String[][] data) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            // Write headers
            writeLine(writer, headers);

            // Write data
            for (String[] row : data) {
                writeLine(writer, row);
            }

            System.out.println("CSV file created successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Helper function to write a single line to the CSV file
    private static void writeLine(BufferedWriter writer, String[] values) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            sb.append(values[i]);
            if (i < values.length - 1) {
                sb.append(",");
            }
        }
        writer.write(sb.toString());
        writer.newLine();
    }
}
