package Test.api.applicationAPI;

import io.restassured.response.Response;

import static Test.api.SpecBuilder.getRequestSpec;
import static Test.api.SpecBuilder.getResponseSpec;
import static io.restassured.RestAssured.given;


public class Request {
    public Response post(String reqGenerate,String baseURL,String endPoint){
        return given(getRequestSpec(baseURL))
                .body(reqGenerate)
                .when().post(endPoint)
                .then().spec(getResponseSpec())
                .extract().response();
    }

    public Response get(String endPoint,String baseURL){
        return given(getRequestSpec(baseURL))
                .when().get(endPoint)
                .then().spec(getResponseSpec())
                .extract().response();
    }
}
