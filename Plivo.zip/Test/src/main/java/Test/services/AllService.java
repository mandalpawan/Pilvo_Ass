package Test.services;


import io.restassured.response.Response;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import static Test.utiles.Request.postAPI;

public class AllService {
    static Response response = null;

    public static void sendsms(String data){
        String URL = "https://api.plivo.com";
        String endpoint = "/v1/Account/{auth_id}/Message/";
        response = postAPI(data,URL,endpoint);
        saveResponseToFile(response);
    }

    public static void saveResponseToFile(Response response) {
        String filePath = "D:\\Test\\Test\\output.csv";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(response.getBody().asString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
